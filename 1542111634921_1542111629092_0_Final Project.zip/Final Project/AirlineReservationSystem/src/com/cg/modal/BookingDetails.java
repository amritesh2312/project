package com.cg.modal;

import javax.validation.constraints.Pattern;

public class BookingDetails 
{
	@Pattern(regexp="[1-9]{0,5}",message="Enter a Valid Booking Id")
	private String bookingId;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
}
